














import React, { useState } from 'react';
import './applier.css';
import Topbar from '../Navbar/Topbar';
import { Link, useNavigate } from 'react-router-dom';
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import { Button } from 'bootstrap';


export default function Applier() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navi = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!username || !password) {
      toast.error('Please fill in both fields');
      return;
    }

    axios.post('http://localhost:5000/fita/check', {
      email: username,
      password: password
    })
    .then((res) => {
      console.log(res.data.message);
      if (res.data.message == 'User found') {
        localStorage.setItem("email", username);
        toast.success("Login successfully!");

        // Clear the input fields after successful login
        setUsername('');
        setPassword('');

        // Navigate to the /card route after a short delay
        setTimeout(() => {
          navi('/card');
        }, 7000); // Adjust the delay as needed
      } else {
        toast.error("Please check user data");
      }
    })
    .catch(err => {
      console.error(err);
      toast.error("An error occurred. Please try again.");
    });
  };

  return (
    <>
    <ToastContainer />
      <Topbar />
      <div className='institution' style={{ marginTop: "180px" }}>
        <h1 className='text-danger'>Recruiter Login</h1>
        <form onSubmit={handleSubmit}>
          <div>
            <label>Username:</label>
            <input 
              type="email" 
              placeholder='User Name'
              value={username} 
              onChange={(e) => setUsername(e.target.value)} 
            />
          </div>
          <div>
            <label>Password:</label>
            <input 
              type="password" 
              placeholder='User Password'
              value={password} 
              onChange={(e) => setPassword(e.target.value)} 
            />
          </div>
          <button 
            type="submit" 
            className='bg-success mt-2 w-100'
            style={{ marginLeft: "5px", borderRadius: "25px" }}
          >
            Login
          </button>

           <Link to={'/userlogin'} style={{textDecoration:"none"}}>
           <button type="submit" className=' mt-3 w-100'  style={{marginLeft:"5px",borderRadius:"25px"}}> User Login Page  </button> 
           </Link> 
          

        </form>
      </div>

    </>
  );
}
